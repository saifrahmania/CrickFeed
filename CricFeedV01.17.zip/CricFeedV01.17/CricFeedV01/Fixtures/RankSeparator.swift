//
//  RankSeparator.swift
//  CricFeedV01
//
//  Created by BJIT on 25/2/23.
//

import Foundation
struct RankSeparator {
    var name:String?
    var image_path:String?
    var position: Int?
    var matches: Int?
    var points: Int?
    var rating: Int?
}


