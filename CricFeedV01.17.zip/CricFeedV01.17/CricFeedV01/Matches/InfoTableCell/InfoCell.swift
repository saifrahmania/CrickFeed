//
//  InfoCell.swift
//  CricFeedV01
//
//  Created by BJIT on 26/2/23.
//

import UIKit

class InfoCell: UITableViewCell {

    @IBOutlet weak var infoCellText: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
